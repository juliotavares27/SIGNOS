let url="dados/dados.xml";

$.ajax(url)
    .done(function (xml) {
        $(xml).find("aries").each(function(){
            $(".title-signos").append(`
                <div class="title-signos">
                    <img class="logo-signo" src="${ $(this).find("logo").text()}">
                    <h4>Nascidos entre</h4>
                    <div style="display:-webkit-inline-box;">
                        <p class="data-inicio">${ $(this).find("dataInicio").text()} </p>&nbsp-&nbsp      
                        <p class="data-fim"> ${ $(this).find("dataFim").text()}</p>
                    </div>                   
                    <h1 class="nome-signo">HORÓSCOPO DE ${ $(this).find("signoNome").text()}</h1>                                    
                </div>
                <div class="textos" style="background-color: ${ $(this).find("color").text()}">
                    <h3>CARACTERÍSTICAS</h3>
                    <p class="paragrafo1">&nbsp&nbsp&nbsp&nbsp${ $(this).find("paragrafo1").text()}</p>
                    <p class="paragrafo2">&nbsp&nbsp&nbsp&nbsp${ $(this).find("paragrafo2").text()}</p>
                    <div class="voltar p-4 col-5">
                        <a href="index.html" class="btn btn-danger" type="button">Página Inicial</a>
                    </div>
                </div>
            `);
        });
    })
    .fail(function(){
        alert("Ocorreu um erro na leitura do arquivo xml.");
    })